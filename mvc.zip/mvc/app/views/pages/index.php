<?php
require APPROOT . '/views/includes/head.php';
?>

<div id="section-landing">
<?php
require APPROOT . '/views/includes/navigation.php';
?>
<h1>A MVC PRACTICE PROJECT</h1>
</div>