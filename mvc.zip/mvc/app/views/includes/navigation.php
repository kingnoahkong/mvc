<!-- an example navigations that can be modified to fit its purpose  -->
<nav class="nav">
  <ul>
    <li>
        <a href="<?php echo URLROOT; ?>/pages/index">Home</a>  
    </li>
    <li>
        <a href="<?php echo URLROOT; ?>/pages/about">About</a>  
    </li>
    <li>
        <a href="<?php echo URLROOT; ?>/pages/projects">Projects</a>  
    </li>
    <li>
        <a href="<?php echo URLROOT; ?>/pages/blog">Blog</a>  
    </li>
    <li>
        <a href="<?php echo URLROOT; ?>/pages/contact">Contact</a>  
    </li>
  </ul>
</nav>