<?php
//app root
define('APPROOT', dirname(dirname(__FILE__)));

//url root (dynamic links)
define('URLROOT', 'localhost/mvc');

// site name aka organisation name
define('SITENAME', 'MVC');