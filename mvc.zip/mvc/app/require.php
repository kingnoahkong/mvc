<?php

// require the lib files and configuration file
  require_once 'lib/Core.php';
  require_once 'lib/controller.php';
  require_once 'lib/db.php';
  require_once 'config/config.php';


//instiate the Core class

    $init = new Core();