<?php

  class Pages extends Controller {
    public function __construct(){
      $this->userModel = $this->model('Users');
    }
    //index / home page
    public function index(){
      $users = $this->userModel->getUsers();
      $data = [
        'title' => 'Home Page',
        'users' => $users
      ];
     $this->view('pages/index', $data);
    }
    //an example about page
    public function about(){
      $this->view('pages/about');
    }
    
  }