<?php

  class Db {
    private $host = 'localhost';
    private $user = 'root';
    private $pwd = '';
    private $db = 'mvc';

    private $stat;
    private $dbhandler;
    private $error;

    public function __construct(){
      $conn = 'mysql:host=' . $this->host . ';dbname=' . $this->db;
      $options = array(PDO::ATTR_ERRMODE    =>PDO::ERRMODE_EXCEPTION,
                       PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                       PDO::ATTR_PERSISTENT =>true);
    
    try {
        $this->dbhandler = new PDO($conn, $this->user, $this->pwd, $options);
    } catch (PDOException $e){
        $this->error = $e->getMessage();
        echo $this->error;
    }
    }

    //enble queries
    public function query($sql){
        $this->stat = $this->dbhandler->prepare($sql);
    }

    //bind values
    public function bind($parms, $value, $type = null){
      switch(is_null($type)){
          case is_int($value): 
            $type = PDO::PARAM_INT;
            break;
          case is_bool($value):
            $type = PDO::PARAM_BOOL;
            break;
          case is_null($value):
            $type = PDO::PARAM_NULL;
            break;  
          default: 
            $type = PDO::PARAM_STR;
      }
      $this->stat->bindValue($parms, $value, $type);
    }

    //execute the prepared statement
    public function execute(){
      return $this->stat->execute();
    }
    //return an array
    public function resultSet(){
      $this->execute();
      return $this->stat->fetchAll(PDO::FETCH_OBJ);
    }
    //get a single row
    public function single(){
      $this->execute();
      return $this->stat->fetch(PDO::FETCH_OBJ);
    }

    //get Row count
    public function rowCount(){
      return $this->stat->rowCount();
    }
  }